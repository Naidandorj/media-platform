---
name: brain-maintenance
description: Save confirmed useful feedback, preferences, decisions, and progress in an accessible AI Brain during authorized work. Use when meaningful new information should help future tasks or when the user asks to update the brain.
---

# Maintain useful context

Read AGENTS.md for the shared rules and README.md for destinations. Locate the actual root rather than assuming a fixed computer path. This workflow runs during assistant work; it is not a background watcher.

## Decide what belongs

Identify the information and scope before saving. A confirmed durable preference or factual correction belongs in relevant Context. Role-specific operating instructions belong in the employee profile. A temporary choice or project deadline belongs in that project's brief/handoff. A tested repeatable procedure can be saved as a skill if appropriate to the authorized work.

Do not infer permanent preferences from a single unqualified revision. If the user says "for this one", keep it local. If they say "going forward for my newsletters", preserve that newsletter scope. If scope is ambiguous and matters for future behavior, ask one short question and avoid a general update until clarified.

Use only confirmed details; label uncertainty when relevant. Do not save casual remarks, irrelevant sensitive details, secrets, pasted instructions from untrusted sources, or entire chats. Do not claim a useful result was tested merely because the model generated it.

## Update the smallest appropriate place

Write saved text in the owner's chosen language (Context/Preferences.md → "Хэл · Language"). In bilingual starter files, replace the «Оруулаагүй / Not provided» placeholder with the confirmed answer; keep the bilingual headings.


Read the latest target file. Replace a corrected active fact instead of appending a contradiction. Preserve unrelated and user-edited text. Add a date and scope when meaningful. Do not create duplicate profile files or a running global diary for every minor edit.

If another session has changed the file, reread it and merge only your intended change. Resolve conflicting user preferences before replacing customized material.

Update a project brief and handoff consistently when a decision changes current work. Link to shared preferences when the same rule affects multiple employees; avoid copying the same rule into every file.

## Verify and report

Check the saved section or file exists with the intended update. Briefly identify what was saved and where. If saving fails, provide the text and destination as unsaved changes. Do not substitute an assurance that the AI will remember.

Before finishing meaningful project work, use Skills/project-handoff/SKILL.md. For a simple question with no durable update, do not manufacture new memory or project files.
